﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Sandra Liu
// CIS 3309
// Feb 7, 2018

// Globals Class
// Class Purpose: Used only to instantiate the Selected Numbers List Object which is used in two places

// Written by Frank Friedman over 100 years ago

namespace BingoGame
{
    public class Globals
    {
        public static SelectedNumbersListType selectedNumbersListObj = new SelectedNumbersListType();
    }  // end Globals class
}  // end Namepsace

    

